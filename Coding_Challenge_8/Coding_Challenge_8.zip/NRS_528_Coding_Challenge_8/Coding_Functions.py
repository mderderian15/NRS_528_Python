# Our coding challenge this week follows from the last exercise that we did in class during Week 8 where we worked with
# functions.

# Convert some of your earlier code into a function. The only rules are:
# 1) You must do more than one thing to your input to the function, and
# 2) the function must take two arguments or more. You must also,
# 3) provide a zip file of example data within your repo.

# Plan the task to take an hour or two, so use one of the simpler examples from our past classes.

# Using Coding Challenge 5 to create a function
import os

base_path = r'C:\NRS 528\NRS_528_Python\Coding_Challenge_8\Coding_Challenge_8_Data'

# Step 1: Import arcpy
import arcpy

# Step 2: Name input shapefile
input_shapefile = os.path.join(base_path, 'BIO_Natural_Heritage_Areas_2023.shp')


# Step 3: Define function

def describe_shpfile(input_Shapefile):
    if arcpy.Exists(input_Shapefile):
        desc = arcpy.Describe(input_Shapefile)
        print("Describing: " + str(input_Shapefile))
        if desc.shapeType == "Polygon":
            print("Shape Type: " + desc.shapeType)

        else:
            print("Shape type is not Polygon")
    else:
        print("Data not found, please check file path")


# Don't forget to add Describe command
describe_shpfile(input_shapefile)

# Repeat for spatial reference


input_shapefile2 = os.path.join(base_path, 'BIO_Natural_Heritage_Areas_2023.shp')


def describe_spref(input_shapefile2):
    if arcpy.Exists(input_shapefile2):
        desc = arcpy.Describe(input_shapefile2)
        print("Describing: " + str(input_shapefile2))
        if desc.spatialReference == "WGS 84":
            print("Spatial Reference: " + desc.spatialReference)

        else:
            print("Spatial Reference is not WGS 84")

    else:
        print("Data not found, please check file path")


describe_spref(input_shapefile2)
