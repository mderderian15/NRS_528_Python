# Our coding challenge this week that improves our practice with rasters from Week 10.
#
# Task 1 - Use what you have learned to process the Landsat files provided, this time, you know you are interested in
# the NVDI index which will use Bands 4 (red, aka vis) and 5 (near-infrared, aka nir) from the Landsat 8 imagery,
# see here for more info about the bands: https://www.usgs.gov/faqs/what-are-band-designations-landsat-satellites.
# Data provided are monthly (a couple are missing due to cloud coverage) during the year 2015 for the State of RI,
# and stored in the file Landsat_data_lfs.zip.
#
# Before you start, here is a suggested workflow:
#
# Extract the Landsat_data_lfs.zip file into a known location. For each month provided, you want to calculate the
# NVDI, using the equation: nvdi = (nir - vis) / (nir + vis)
# https://en.wikipedia.org/wiki/Normalized_difference_vegetation_index. Consider using the Raster Calculator Tool in
# ArcMap and using "Copy as Python Snippet" for the first calculation. The only rule is, you should run your script
# once, and generate the NVDI for ALL MONTHS provided. As part of your code submission, you should also provide a
# visualization document (e.g. an ArcMap layout in PDF format), showing the patterns for an area of RI that you find
# interesting.

# Calculating NDVI
# NIR = spectral reflectance measurements from near infrared regions (Band 5)
# VIS = spectral measurements from red/ visible region (Band 4)

import os
import arcpy

# Setting the base path
base_path = r"C:\NRS 528\NRS_528_Python\Coding_Challenge_10\Landsat_Imagery"
ndvi_directory = os.path.join(base_path, "NDVI Outputs")

# Directory check
if not os.path.exists(ndvi_directory):
    os.makedirs(ndvi_directory)

# Set Arcpy work environment
arcpy.env.workspace = base_path
arcpy.env.overwriteOutput = True

# Scanning for subfolders
subfolders = [os.path.join(base_path, folder)
             for folder in os.listdir(base_path)
             if os.path.isdir(os.path.join(base_path, folder))]
# Looping through subfolders
for subfolder in subfolders:
    arcpy.env.workspace = subfolder

    # List B4 and B5 files
    b4_files = arcpy.ListRasters("*B4*.tif")
    b5_files = arcpy.ListRasters("*B5*.tif")

    if b4_files and b5_files:
        b4_raster = arcpy.Raster(os.path.join(subfolder, b4_files[0]))
        b5_raster = arcpy.Raster(os.path.join(subfolder, b5_files[0]))

# Calculate NDVI
        calculate_ndvi = (b5_raster - b4_raster) / (b5_raster + b4_raster)

        ndvi_path = os.path.join(ndvi_directory, f"NDVI_{os.path.basename(subfolder)}.tif")

        calculate_ndvi.save(ndvi_path)
        print(f"NDVI saved to: {ndvi_path}")
    else:
        print(f"No B4 or B5 raster files found in {subfolder}")

print("Workflow complete")

#   with arcpy.EnvManager(scratchWorkspace=r"C:\NRS 528\NRS_528_Python\Coding_Challenge_10\201502"):
#       output_raster = arcpy.ia.RasterCalculator(
#           expression=r'( "C:\NRS 528\NRS_528_Python\Coding_Challenge_10\201502'
#                   r'\LC08_L1TP_012031_20150201_20170301_01_T1_B5.tif" -  "C:\NRS '
#                    r'528\NRS_528_Python\Coding_Challenge_10\201502\LC08_L1TP_012031_20150201_20170301_01_T1_B4'
#                    r'.tif")/'
#                    r'( "C:\NRS '
#                   r'528\NRS_528_Python\Coding_Challenge_10\201502\LC08_L1TP_012031_20150201_20170301_01_T1_B5'
#                    r'.tif" +'
#                    r'"C:\NRS 528\NRS_528_Python\Coding_Challenge_10\201502'
#                   r'\LC08_L1TP_012031_20150201_20170301_01_T1_B4.tif")'
#       )
# output_raster.save(r"C:\NRS 528\NRS_528_Python\Coding_Challenge_10\201502\RasterCalc")
